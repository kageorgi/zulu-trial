from django.urls import path
from . import stkPush
from . import callback

urlpatterns = [
    path('stk-push/', stkPush.initiate_stk_push, name='stk_push'),
    path('callback/', callback.process_stk_callback, name='mpesa_callback'),
]