import requests
from datetime import datetime
import json
import base64
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
from .models import MpesaTransaction

# A helper function to generate the M-Pesa password
def get_mpesa_password(shortcode, passkey, timestamp):
    """
    Generates the M-Pesa password for the STK Push request.
    """
    data_to_encode = f"{shortcode}{passkey}{timestamp}"
    encoded_string = base64.b64encode(data_to_encode.encode()).decode('utf-8')
    return encoded_string

# A helper function to get the access token from Safaricom
def get_access_token():
    """
    Gets a new access token from the Daraja API.
    """
    consumer_key = os.environ.get('MPESA_CONSUMER_KEY')
    consumer_secret = os.environ.get('MPESA_CONSUMER_SECRET')
    auth_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
    
    if not consumer_key or not consumer_secret:
        print("Error: MPESA_CONSUMER_KEY or MPESA_CONSUMER_SECRET not set in environment variables.")
        return None

    try:
        response = requests.get(auth_url, auth=(consumer_key, consumer_secret))
        response.raise_for_status() 
        return response.json().get('access_token')
    except requests.exceptions.RequestException as e:
        print(f"Error getting access token: {e}")
        return None

@csrf_exempt
def initiate_stk_push(request):
    """
    Initiates an STK Push payment request to the M-Pesa API.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST requests are allowed.'}, status=405)

    try:
        access_token = get_access_token()
        if not access_token:
            return JsonResponse({'error': 'Failed to retrieve access token.'}, status=500)
        
        data = json.loads(request.body)
        amount = data.get('Amount')
        phone = data.get('PhoneNumber')
        account_reference = data.get('AccountReference')

        if not all([amount, phone, account_reference]):
            return JsonResponse({'error': 'Missing required fields (Amount, PhoneNumber, AccountReference).'}, status=400)
        
        # M-Pesa API credentials and settings
        passkey = os.environ.get('MPESA_PASSKEY', 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919')
        business_short_code = os.environ.get('MPESA_SHORTCODE', '174379')
        
        process_request_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
        callback_url = "https://efae6e8868b8.ngrok-free.app/daraja/callback/"

        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        password = get_mpesa_password(business_short_code, passkey, timestamp)
        
        stk_push_payload = {
            'BusinessShortCode': business_short_code,
            'Password': password,
            'Timestamp': timestamp,
            'TransactionType': 'CustomerPayBillOnline',
            'Amount': amount,
            'PartyA': phone,
            'PartyB': business_short_code,
            'PhoneNumber': phone,
            'CallBackURL': callback_url,
            'AccountReference': account_reference,
            'TransactionDesc': 'STK Push to Paybill'
        }

        response = requests.post(
            process_request_url, 
            headers={'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}, 
            json=stk_push_payload
        )
        response.raise_for_status() 

        response_data = response.json()
        
        if response_data.get('ResponseCode') == "0":
            checkout_request_id = response_data.get('CheckoutRequestID')
            merchant_request_id = response_data.get('MerchantRequestID')

            # Create a pending transaction record in the database
            MpesaTransaction.objects.create(
                merchant_request_id=merchant_request_id,
                checkout_request_id=checkout_request_id,
                amount=amount,
                phone_number=phone
            )

            return JsonResponse({
                'CheckoutRequestID': checkout_request_id, 
                'CustomerMessage': response_data.get('CustomerMessage', 'Success! Awaiting M-Pesa pin confirmation.')
            })
        else:
            return JsonResponse({
                'error': 'STK push failed.',
                'message': response_data.get('ResponseDescription', 'An unknown error occurred.')
            }, status=400)

    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON in request body.'}, status=400)
    except requests.exceptions.RequestException as e:
        print(f"Request to M-Pesa failed: {e}")
        return JsonResponse({'error': f'Failed to connect to M-Pesa API: {e}'}, status=500)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return JsonResponse({'error': f'An internal server error occurred: {e}'}, status=500)