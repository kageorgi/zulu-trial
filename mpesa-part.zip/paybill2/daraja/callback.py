import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
import pytz # Import the pytz library
from django.conf import settings # Import settings
from .models import MpesaTransaction # Import the model

@csrf_exempt
def process_stk_callback(request):
    """
    Handles the asynchronous M-Pesa STK Push callback.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=405)
    
    try:
        stk_callback_response = json.loads(request.body)
        
        callback_data = stk_callback_response.get('Body', {}).get('stkCallback', {})
        
        # Get the unique identifier to find the transaction
        checkout_request_id = callback_data.get('CheckoutRequestID')

        if not checkout_request_id:
            print("Error: CheckoutRequestID is missing in the callback.")
            return JsonResponse({'error': 'CheckoutRequestID is missing'}, status=400)
            
        # Find the pending transaction in our database
        try:
            transaction = MpesaTransaction.objects.get(checkout_request_id=checkout_request_id)
        except MpesaTransaction.DoesNotExist:
            print(f"Error: Transaction with CheckoutRequestID {checkout_request_id} not found.")
            return JsonResponse({'error': 'Transaction not found'}, status=404)

        result_code = callback_data.get('ResultCode')
        result_desc = callback_data.get('ResultDesc')

        # Update the transaction with callback details
        transaction.result_code = result_code
        transaction.result_desc = result_desc

        if result_code == 0:
            # Transaction was successful
            metadata = callback_data.get('CallbackMetadata', {}).get('Item', [])
            metadata_dict = {item.get('Name'): item.get('Value') for item in metadata}

            mpesa_receipt_number = metadata_dict.get('MpesaReceiptNumber')
            transaction_date_str = metadata_dict.get('TransactionDate')
            
            # Update the record with successful transaction data
            transaction.mpesa_receipt_number = mpesa_receipt_number
            transaction.status = 'Completed'
            
            # Parse the transaction date string to a datetime object
            if transaction_date_str:
                # Get the project's timezone from settings
                tz = pytz.timezone(settings.TIME_ZONE)
                # Create a naive datetime object from the M-Pesa string
                naive_datetime = datetime.strptime(str(transaction_date_str), '%Y%m%d%H%M%S')
                # Make the datetime timezone-aware before saving
                transaction.transaction_date = tz.localize(naive_datetime)
            
            print(f"Transaction {checkout_request_id} completed successfully.")

        else:
            # Transaction failed or was canceled
            transaction.status = 'Failed'
            print(f"Transaction {checkout_request_id} failed with code {result_code}.")

        transaction.save() # Save the updated record to the database

    except json.JSONDecodeError:
        print("Error: Invalid JSON received in callback.")
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return JsonResponse({'error': 'Internal server error'}, status=500)

    # Safaricom requires a response with an HTTP 200 OK status to acknowledge receipt.
    return JsonResponse({'ResultCode': 0, 'ResultDesc': 'Success'}, status=200)