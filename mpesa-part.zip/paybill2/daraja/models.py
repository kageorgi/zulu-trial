from django.db import models

class MpesaTransaction(models.Model):
    # Unique ID from the initial STK Push request
    merchant_request_id = models.CharField(max_length=255, unique=True, null=True, blank=True)
    
    # Unique ID to track the transaction
    checkout_request_id = models.CharField(max_length=255, unique=True, null=True, blank=True)
    
    # Result code from the final callback (0 for success)
    result_code = models.CharField(max_length=10, null=True, blank=True)
    
    # Description of the result
    result_desc = models.CharField(max_length=255, null=True, blank=True)
    
    # Amount paid
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    # M-Pesa's unique receipt number for successful transactions
    mpesa_receipt_number = models.CharField(max_length=255, null=True, blank=True)
    
    # The date and time of the transaction
    transaction_date = models.DateTimeField(null=True, blank=True)
    
    # The phone number that initiated the payment
    phone_number = models.CharField(max_length=20, null=True, blank=True)
    
    # Our internal status for the transaction (e.g., Pending, Completed, Failed)
    status = models.CharField(max_length=20, default='Pending')
    
    # Timestamps for when the record was created and last updated
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.mpesa_receipt_number or 'Pending'} - {self.phone_number}"