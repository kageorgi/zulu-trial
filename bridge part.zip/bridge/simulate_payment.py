import requests
import json
import time

# Webhook endpoint
WEBHOOK_URL = "http://localhost:8000/payment-webhook"

# Meter test cases with specific amounts and transaction IDs
test_data = [
    {"meter_no": "25051309630001", "amount": 100, "transaction_id": "TXN001"},
    {"meter_no": "25051309630002", "amount": 150, "transaction_id": "TXN002"},
    {"meter_no": "25051309630003", "amount": 175, "transaction_id": "TXN003"},
    {"meter_no": "25051309630004", "amount": 120, "transaction_id": "TXN004"},
    {"meter_no": "25051309630005", "amount": 200, "transaction_id": "TXN005"}
]

# Common MSISDN for all (can be changed if needed)
msisdn = "254799319838"

# Send POST requests for each test meter
for test in test_data:
    payload = {
        "transaction_id": test["transaction_id"],
        "meter_no": test["meter_no"],
        "amount": test["amount"],
        "msisdn": msisdn
    }

    response = requests.post(
        WEBHOOK_URL,
        headers={"Content-Type": "application/json"},
        data=json.dumps(payload)
    )

    print(f"Meter: {test['meter_no']} | TXN: {test['transaction_id']} | Amount: {test['amount']}")
    print("Status Code:", response.status_code)
    print("Response:", response.json())
    print("-" * 40)

    time.sleep(1)  # Delay between requests (optional)
