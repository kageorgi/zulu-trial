# this is the best one cause they will not pay all at once 😆😆😆
import requests
import json

# Webhook endpoint
WEBHOOK_URL = "http://localhost:8000/payment-webhook"

# Sample payment payload
payload = {
    "transaction_id": "TDFRGTKY345",
    "meter_no": "25051309630003",
    "amount": 1000,
    "msisdn": "254799319838"
}

# Send the POST request
response = requests.post(
    WEBHOOK_URL,
    headers={"Content-Type": "application/json"},
    data=json.dumps(payload)
)

# Output the response
print("Status Code:", response.status_code)
print("Response:", response.json())
