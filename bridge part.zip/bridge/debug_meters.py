import requests
import json
from bridge2 import get_acrel_token, ACREL_METER_LIST_URL

token = get_acrel_token()

headers = {
    "Content-Type": "application/json",
    "token": token
}

response = requests.post(
    ACREL_METER_LIST_URL,
    headers=headers,
    json={}
)

res_data = response.json()

print("\n🔍 Meters currently returned from Acrel:")
for item in res_data["data"]:
    print(f"MeterSN: {item['meterSn']}  →  MeterID: {item['meterId']}")
