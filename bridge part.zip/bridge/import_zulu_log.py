import sqlite3
import re
from datetime import datetime

DATABASE_FILE = 'zulu_plaza.db'
LOG_FILE = 'bridge2.log' # <<< IMPORTANT: Update this to your actual log file name

# <<< NEW: Shop to Meter Mapping >>>
# This dictionary maps a Meter Number (as a string) to its corresponding Shop No.
# You can expand this dictionary with all your shop and meter mappings.
SHOP_METER_MAPPING = {
    "25051309630005": "A",
    "25051309630004": "B",
    "25051309630003": "F",
    "25051309630001": "G",
    "25051309630002": "H",
    # Add more mappings here as needed, e.g.:
    # "AnotherMeterNo": "ShopX",
}
# <<< END NEW >>>

def initialize_db():
    """Initializes the SQLite database and creates the necessary tables."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()

    # Clients table: meter_no is UNIQUE here as phone_number isn't always available in success logs.
    # phone_number is nullable for now.
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Clients (
            client_id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone_number TEXT UNIQUE, -- Made nullable as it's not in success logs
            meter_no TEXT NOT NULL UNIQUE, -- Used as the primary identifier for clients
            default_shop_no TEXT, -- Now populated from the mapping
            current_token_balance REAL DEFAULT 0.00 NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ''')
    cursor.execute('''
        CREATE TRIGGER IF NOT EXISTS update_clients_updated_at
        AFTER UPDATE ON Clients
        FOR EACH ROW
        BEGIN
            UPDATE Clients SET updated_at = CURRENT_TIMESTAMP WHERE client_id = NEW.client_id;
        END;
    ''')

    # Transactions table: records each individual purchase.
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Transactions (
            transaction_id_db INTEGER PRIMARY KEY AUTOINCREMENT, -- Internal DB primary key
            external_transaction_id TEXT UNIQUE, -- From log (e.g., TXN: TF42HI7J456) to prevent duplicates
            client_id INTEGER NOT NULL,
            shop_no TEXT, -- Now populated from the mapping
            amount_paid REAL NOT NULL,
            date_paid TEXT NOT NULL,
            time_paid TEXT NOT NULL,
            tokens_generated REAL NOT NULL,
            log_timestamp TEXT, -- Original full timestamp from log
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id) REFERENCES Clients(client_id)
        );
    ''')
    conn.commit()
    conn.close()

def import_log_data():
    """Reads the log file, parses success entries, and imports data into SQLite."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()

    # Regex to parse [INFO] SALEPOWER Success lines
    # Groups: 1=date, 2=time, 3=meter, 4=amount, 5=txn_id
    log_pattern_success = re.compile(
        r"(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2}),\d+\s+\[INFO\]\s+SALEPOWER Success\s+-\s+Meter:\s+(\d+)\s+\|\s+Amount:\s+(\d+)\s+\|\s+TXN:\s+([A-Za-z0-9]+)"
    )

    processed_transactions = 0
    skipped_duplicates = 0
    skipped_errors = 0
    unmapped_shops = 0

    try:
        with open(LOG_FILE, 'r') as f:
            for line_num, line in enumerate(f, 1):
                match_success = log_pattern_success.match(line)
                if match_success:
                    # Extract data from a successful log line
                    date_part, time_part, meter_no, amount_str, external_transaction_id = match_success.groups()
                    amount_paid = float(amount_str)
                    tokens_generated = amount_paid / 30.0

                    # <<< NEW: Use the mapping to get shop_no >>>
                    shop_no = SHOP_METER_MAPPING.get(meter_no, "UNKNOWN_SHOP") # Defaults to "UNKNOWN_SHOP" if meter_no not in map
                    if shop_no == "UNKNOWN_SHOP":
                        unmapped_shops += 1
                    # <<< END NEW >>>

                    phone_number = None # Still not available in success log lines

                    try:
                        # 1. Find or create the client based on meter_no (unique for clients for this import)
                        cursor.execute("SELECT client_id FROM Clients WHERE meter_no = ?", (meter_no,))
                        client_data = cursor.fetchone()

                        client_id = None
                        if client_data:
                            client_id = client_data[0]
                        else:
                            # Client doesn't exist, create new client record
                            # phone_number will be NULL unless manually updated later
                            # default_shop_no is now populated from the mapping
                            cursor.execute(
                                "INSERT INTO Clients (meter_no, default_shop_no, current_token_balance, phone_number) VALUES (?, ?, ?, ?)",
                                (meter_no, shop_no, 0.00, phone_number)
                            )
                            client_id = cursor.lastrowid # Get the ID of the newly inserted client

                        # Check if this specific transaction (by its external_transaction_id) has already been imported
                        cursor.execute("SELECT transaction_id_db FROM Transactions WHERE external_transaction_id = ?", (external_transaction_id,))
                        existing_txn = cursor.fetchone()

                        if not existing_txn:
                            # 2. Insert the new transaction record
                            cursor.execute(
                                "INSERT INTO Transactions (client_id, external_transaction_id, shop_no, amount_paid, date_paid, time_paid, tokens_generated, log_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                (client_id, external_transaction_id, shop_no, amount_paid, date_part, time_part, tokens_generated, f"{date_part} {time_part}:00") # Reconstruct full timestamp
                            )

                            # 3. Update the client's total token balance
                            cursor.execute(
                                "UPDATE Clients SET current_token_balance = current_token_balance + ? WHERE client_id = ?",
                                (tokens_generated, client_id)
                            )
                            processed_transactions += 1
                        else:
                            skipped_duplicates += 1

                    except sqlite3.IntegrityError as e:
                        print(f"Database Integrity Error on line {line_num}: {line.strip()} - {e}")
                    except Exception as e:
                        print(f"Error processing success line {line_num}: {line.strip()} - {e}")
                elif '[ERROR]' in line:
                    skipped_errors += 1

    except FileNotFoundError:
        print(f"Error: Log file '{LOG_FILE}' not found. Please ensure the path is correct.")
        return
    except Exception as e:
        print(f"An unexpected error occurred during file reading or initial setup: {e}")
        return

    conn.commit()
    conn.close()
    print(f"\n--- Data Import Summary ---")
    print(f"Log file '{LOG_FILE}' processed into '{DATABASE_FILE}'.")
    print(f"Successful transactions imported: {processed_transactions}")
    print(f"Duplicate transactions skipped: {skipped_duplicates}")
    print(f"Error lines encountered (skipped for import): {skipped_errors}")
    if unmapped_shops > 0:
        print(f"Warnings: {unmapped_shops} transactions had meter numbers not found in SHOP_METER_MAPPING and were assigned 'UNKNOWN_SHOP'.")
    print("Database setup and data import script finished.")

# --- Main execution ---
if __name__ == "__main__":
    initialize_db()
    import_log_data()

    # After running, you can use your VSCode SQLite extension to browse the 'zulu_plaza.db' file
    # and see the 'Clients' and 'Transactions' tables populated.