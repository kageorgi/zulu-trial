import redis
import json
import time
import uuid
import logging
import requests
from datetime import datetime, timedelta

# Redis connection
r = redis.Redis(host='localhost', port=6379, db=0)

# Token Cache
token_cache = {
    "token": None,
    "expires_at": datetime.min
}

# Acrel Config (NEW ENDPOINTS)
ACREL_USERNAME = "chacaenergy"
ACREL_PASSWORD_HASHED = "e4e4be826c6be95d152e4f0696724d00"  # Already hashed
ACREL_LOGIN_URL = "https://iot.acrel-eem.com/basic/prepayment/app/appUserLogin"
ACREL_PROJECT_LIST_URL = "https://iot.acrel-eem.com/basic/prepayment/app/appProjectList"
ACREL_METER_LIST_URL = "https://iot.acrel-eem.com/basic/prepayment/app/appProjectMeterList"
ACREL_SALEPOWER_URL = "https://iot.acrel-eem.com/basic/prepayment/app/SalePower"  # Fixed URL

# Logging setup
logging.basicConfig(
    filename='bridge2.log',
    filemode='a',
    format='%(asctime)s [%(levelname)s] %(message)s',
    level=logging.INFO
)

# Meter cache
meter_cache = {}

def get_acrel_token(force_refresh=False):
    if not force_refresh and token_cache["token"] and datetime.now() < token_cache["expires_at"]:
        return token_cache["token"]

    response = requests.post(
        ACREL_LOGIN_URL,
        headers={"Content-Type": "application/json"},
        json={
            "username": ACREL_USERNAME,
            "password": ACREL_PASSWORD_HASHED,
            "type": "0"
        }
    )
    print(f"🔐 Login Response: {response.status_code} | {response.text}")

    res_data = response.json()

    if res_data.get("success") != "1" or not res_data.get("data"):
        raise Exception(f"Login failed: {res_data}")

    token = res_data["data"]
    token_cache["token"] = token
    token_cache["expires_at"] = datetime.now() + timedelta(minutes=25)
    return token

def get_meter_id(meter_sn, project_id="3763"): #changed project_ID to match andrew's
    if meter_sn in meter_cache:
        return meter_cache[meter_sn]

    token = get_acrel_token()
    response = requests.post(
        ACREL_METER_LIST_URL,
        headers={
            "Content-Type": "application/json",
            "token": token
        },
        json={
            "keyword": "",
            "projectId": project_id,
            "energyId": "1",
            "pageSize": 20,
            "pageIndex": 1
        }
    )
    print(f"📡 Meter List Response: {response.status_code} | {response.text}")

    res_data = response.json()

    if res_data.get("success") != "1" or "data" not in res_data or "list" not in res_data["data"]:
        raise Exception(f"Failed to fetch meter list: {res_data}")

    meter_list = res_data["data"]["list"]
    for item in meter_list:
        if str(item.get("meterSn")) == str(meter_sn):
            meter_id = item.get("id")
            meter_cache[meter_sn] = meter_id
            return meter_id

    raise Exception(f"Meter ID not found for SN: {meter_sn}")

def send_salepower(meter_id, amount, sale_id, retry=True):
    token = get_acrel_token(force_refresh=False)
    payload = {
        "meterId": str(meter_id),
        "saleMoney": str(int(amount) * 100),  # ✅ Corrected: Must be integer
        "buyType": "1",
        "saleId": str(sale_id)
    }
    headers = {
        "Content-Type": "application/json",
        "token": token
    }

    print(f"🚀 Calling send_salepower: {payload}")
    response = requests.post(ACREL_SALEPOWER_URL, headers=headers, json=payload)
    print(f"📨 SALEPOWER response: {response.status_code} | {response.text}")

    try:
        res_data = response.json()
    except Exception:
        raise Exception(f"Non-JSON response: {response.text}")

    error_msg = res_data.get("errorMsg", "")

    if res_data.get("success") != "1":
        if "TOKEN错误" in error_msg and retry:
            print("⚠️ TOKEN错误: refreshing token and retrying once...")
            token_cache["token"] = None
            token_cache["expires_at"] = datetime.min
            get_acrel_token(force_refresh=True)
            return send_salepower(meter_id, amount, sale_id, retry=False)
        else:
            raise Exception(f"SALEPOWER failed: {error_msg or res_data}")

    return res_data

def process_payment_event(event_json):
    try:
        print("🛠 process_payment_event called")
        event = json.loads(event_json)

        if "payload" not in event:
            raise ValueError("Missing 'payload' in event")

        data = event["payload"]
        print("🧪 Parsed JSON payload:", data)

        meter_sn = data.get("meter_no")
        amount = data.get("amount")
        transaction_id = data.get("transaction_id") or str(uuid.uuid4())

        print(f"🔧 Extracted: meter_sn={meter_sn}, amount={amount}, txn={transaction_id}")

        if not meter_sn or amount is None:
            raise ValueError("Missing meter_no or amount in event")

        meter_id = get_meter_id(meter_sn)
        print(f"🔌 Resolved meter_id: {meter_id}")

        result = send_salepower(meter_id, amount, transaction_id)
        print("📬 SALEPOWER success result:", result)

        logging.info(f"SALEPOWER Success - Meter: {meter_sn} | Amount: {amount} | TXN: {transaction_id}")
        print(f"✅ Processed payment for meter {meter_sn}")

    except Exception as e:
        logging.error(f"SALEPOWER Failed - Error: {str(e)} | Event: {event_json}")
        r.lpush("payment_dlq", event_json)
        print(f"❌ Error: {str(e)} - Event pushed to DLQ")

def run_worker():
    print("🚀 Bridge Worker Started...")
    while True:
        result = r.brpop("payment_queue", timeout=5)
        if result:
            print("📥 Event Pulled from Redis!")
            _, event = result
            process_payment_event(event.decode("utf-8"))
        else:
            print("⌛ Queue empty... waiting.")
        time.sleep(1)

if __name__ == "__main__":
    run_worker()
