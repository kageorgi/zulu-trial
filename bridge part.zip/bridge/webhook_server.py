from fastapi import FastAPI, Request
from datetime import datetime
import json
import redis

app = FastAPI()

# ✅ Connect to Redis
r = redis.Redis(host='localhost', port=6379, db=0)

@app.post("/payment-webhook")
async def payment_webhook(request: Request):
    data = await request.json()

    print("\n📥 Payment Received!")
    print(json.dumps(data, indent=4))

    # ✅ Push to Redis queue
    payment_event = {
        "timestamp": datetime.now().isoformat(),
        "payload": data
    }

    r.lpush("payment_queue", json.dumps(payment_event))

    return {"status": "success", "message": "Payment received"}
