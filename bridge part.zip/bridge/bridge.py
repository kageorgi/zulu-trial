import redis
import json
import time
import base64
import requests
from datetime import datetime, timedelta
from Crypto.Cipher import AES

# Redis
r = redis.Redis(host='localhost', port=6379, db=0)

# Acrel Token Cache
token_cache = {
    "token": None,
    "expires_at": datetime.min
}

# Acrel Auth Info
ACREL_USERNAME = "chacaenergy"
ACREL_PASSWORD = "Chaca001"
ACREL_LOGIN_URL = "https://iot.acrel.cn/basic/prepayment/auth_user/login"
ACREL_SALEPOWER_URL = "https://iot.acrel.cn/basic/prepayment/entry/home/control"
ACREL_AES_KEY = b"1234567890123456"
ACREL_AES_IV = b"1234567890123456"

# Gateway Serial Number (from Acrel setup)
GATEWAY_SN = "2501309630012"

def pad16(data: bytes):
    while len(data) % 16 != 0:
        data += b'\x00'
    return data

def encrypt_credentials():
    credentials = json.dumps({
        "LoginName": ACREL_USERNAME,
        "PassWord": ACREL_PASSWORD
    }).encode("utf-8")

    cipher = AES.new(ACREL_AES_KEY, AES.MODE_CBC, ACREL_AES_IV)
    encrypted = cipher.encrypt(pad16(credentials))
    return base64.b64encode(encrypted).decode("utf-8")

def get_acrel_token():
    if token_cache["token"] and datetime.now() < token_cache["expires_at"]:
        return token_cache["token"]

    encrypted = encrypt_credentials()
    response = requests.post(
        ACREL_LOGIN_URL,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data={"params": encrypted}
    )

    res_data = response.json()
    token = res_data["data"]["token"]
    token_cache["token"] = token
    token_cache["expires_at"] = datetime.now() + timedelta(minutes=25)  # Expires in ~30min
    print("🔐 Fetched new Acrel token")

    return token

def send_salepower(meter_sn, amount, buy_times):
    token = get_acrel_token()
    payload = {
        "gatewaySn": GATEWAY_SN,
        "meterSn": meter_sn,
        "method": "SALEPOWER",
        "value": {
            "SaleMoney": float(amount),
            "BuyTimes": int(buy_times)
        }
    }

    headers = {
        "Content-Type": "application/json",
        "token": token
    }

    response = requests.post(ACREL_SALEPOWER_URL, headers=headers, json=payload)
    res_data = response.json()

    print(f"📤 Sent SALEPOWER for meter {meter_sn} | Result: {res_data}")

    if res_data.get("success") != "1":
        raise Exception(f"SALEPOWER failed: {res_data.get('errorMsg')}")

def process_payment_event(event_json):
    try:
        event = json.loads(event_json)
        data = event["payload"]

        # Extract relevant fields (customize as per your system)
        meter_sn = data["meter_no"]
        amount = data["amount"]
        buy_times = data.get("buy_times", 1)  # You can track this from DB later

        send_salepower(meter_sn, amount, buy_times)

        print(f"✅ Processed payment for meter {meter_sn} at {event['timestamp']}")
    except Exception as e:
        print(f"❌ Error processing event: {str(e)}")
        # Optionally push to DLQ or retry queue here

def run_worker():
    print("Bridge Worker Started...")
    while True:
        _, event = r.brpop("payment_queue", timeout=5)
        if event:
            process_payment_event(event)
        time.sleep(1)

if __name__ == "__main__":
    run_worker()
