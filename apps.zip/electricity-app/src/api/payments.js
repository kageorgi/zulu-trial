
import client from "./client";

export async function initiatePaymentApi({ amount }) {
  const res = await client.post("/payments/initiate/", { amount: Number(amount) });
  return res.data; // { status: "pending" | "success" | "failed", reference: "...", message?: "" }
}

export async function getPaymentHistoryApi({ page = 1 }) {
  const res = await client.get(`/payments/history/?page=${page}`);
  return res.data; // { results: [...], count, next, previous }
}

export async function getPaymentStatusApi(reference) {
  const res = await client.get(`/payments/status/${reference}/`);
  return res.data; // { status: "pending" | "success" | "failed", message?: "" }
}
