
import client from "./client";

export async function loginApi({ username, password }) {
  const res = await client.post("/auth/login/", { username, password });
  return res.data; // { token: "...", user: {...} }
}

export async function meApi() {
  const res = await client.get("/auth/me/");
  return res.data;
}
