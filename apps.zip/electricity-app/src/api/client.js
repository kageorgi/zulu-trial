
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";

// TODO: change this to your actual backend base URL
export const BASE_URL = "http://YOUR-DJANGO-API-URL.com/api";

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 20000,
});

// Attach token if present
client.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem("token");
    if (token) {
      config.headers = config.headers || {};
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default client;
