
import React from "react";
import { Card, Text, Badge } from "react-native-paper";

function StatusBadge({ status }) {
  const label = (status || "").toUpperCase();
  return <Badge style={{ alignSelf: "flex-start", marginTop: 8 }}>{label}</Badge>;
}

export default function PaymentCard({ payment }) {
  const amount = payment?.amount ?? 0;
  const created = payment?.created_at ?? payment?.timestamp ?? "";
  const status = payment?.status ?? "unknown";
  const reference = payment?.reference ?? payment?.id ?? "";

  return (
    <Card style={{ padding: 16 }}>
      <Text variant="titleSmall">KES {Number(amount).toLocaleString()}</Text>
      <Text>Ref: {String(reference)}</Text>
      <Text>Date: {String(created)}</Text>
      <StatusBadge status={status} />
    </Card>
  );
}
