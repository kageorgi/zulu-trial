
import React, { useState } from "react";
import { View } from "react-native";
import { Button, Card, TextInput, Text, ActivityIndicator, Snackbar } from "react-native-paper";
import { useMutation, useQuery } from "@tanstack/react-query";
import { initiatePaymentApi, getPaymentStatusApi } from "../api/payments";

export default function PaymentScreen() {
  const [amount, setAmount] = useState("");
  const [snack, setSnack] = useState({ visible: false, message: "" });

  const paymentMutation = useMutation({
    mutationFn: ({ amount }) => initiatePaymentApi({ amount }),
  });

  // naive poller for payment status after initiating
  const [reference, setReference] = useState(null);
  useQuery({
    queryKey: ["paymentStatus", reference],
    queryFn: async () => {
      if (!reference) return null;
      const res = await getPaymentStatusApi(reference);
      if (res?.status && res.status !== "pending") {
        setSnack({ visible: true, message: res.status === "success" ? "Payment successful" : "Payment failed" });
      }
      return res;
    },
    enabled: Boolean(reference),
    refetchInterval: (data) => (data?.status === "pending" ? 2500 : false),
  });

  const onPay = async () => {
    const num = Number(amount);
    if (!num || num <= 0) return setSnack({ visible: true, message: "Enter a valid amount" });
    try {
      const res = await paymentMutation.mutateAsync({ amount: num });
      setReference(res?.reference ?? null);
      if (res?.message) setSnack({ visible: true, message: res.message });
    } catch (e) {
      setSnack({ visible: true, message: "Payment init failed" });
    }
  };

  return (
    <View style={{ flex: 1, padding: 16, gap: 12 }}>
      <Text variant="titleMedium">Make a Payment</Text>
      <Card style={{ padding: 16 }}>
        <TextInput
          label="Amount"
          keyboardType="numeric"
          value={amount}
          onChangeText={setAmount}
          style={{ marginBottom: 12 }}
        />
        <Button mode="contained" onPress={onPay} disabled={paymentMutation.isPending}>
          {paymentMutation.isPending ? <ActivityIndicator animating /> : "Pay Now"}
        </Button>
      </Card>
      {reference ? <Text style={{ marginTop: 8 }}>Reference: {reference}</Text> : null}

      <Snackbar visible={snack.visible} onDismiss={() => setSnack({ visible: false, message: "" })} duration={2500}>
        {snack.message}
      </Snackbar>
    </View>
  );
}
