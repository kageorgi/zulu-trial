
import React, { useState } from "react";
import { View, KeyboardAvoidingView, Platform } from "react-native";
import { Button, TextInput, Text, ActivityIndicator } from "react-native-paper";
import { useAuth } from "../context/AuthContext";

export default function LoginScreen() {
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onLogin = async () => {
    setError("");
    setLoading(true);
    try {
      await login(username.trim(), password);
    } catch (e) {
      setError("Invalid credentials or server unreachable.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1, justifyContent: "center", padding: 24 }}>
      <Text variant="headlineSmall" style={{ marginBottom: 16 }}>Welcome back</Text>
      <TextInput label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" style={{ marginBottom: 12 }} />
      <TextInput label="Password" value={password} onChangeText={setPassword} secureTextEntry style={{ marginBottom: 8 }} />
      {error ? <Text style={{ color: "red", marginBottom: 8 }}>{error}</Text> : null}
      <Button mode="contained" onPress={onLogin} disabled={loading}>
        {loading ? <ActivityIndicator animating={true} /> : "Login"}
      </Button>
    </KeyboardAvoidingView>
  );
}
