
import React from "react";
import { View, RefreshControl, FlatList } from "react-native";
import { Button, Card, Text } from "react-native-paper";
import { useQuery } from "@tanstack/react-query";
import { getPaymentHistoryApi } from "../api/payments";
import PaymentCard from "../components/PaymentCard";
import { useNavigation } from "@react-navigation/native";

export default function DashboardScreen() {
  const nav = useNavigation();
  const { data, refetch, isFetching } = useQuery({
    queryKey: ["history", { page: 1 }],
    queryFn: () => getPaymentHistoryApi({ page: 1 }),
  });

  const results = data?.results ?? [];

  return (
    <View style={{ flex: 1 }}>
      <View style={{ padding: 16, gap: 12 }}>
        <Text variant="titleMedium">Dashboard</Text>
        <Button mode="contained" onPress={() => nav.navigate("Payment")}>Make Payment</Button>
      </View>

      <FlatList
        data={results}
        keyExtractor={(item, idx) => String(item.id ?? idx)}
        refreshControl={<RefreshControl refreshing={isFetching} onRefresh={refetch} />}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        ListHeaderComponent={<Text variant="titleSmall" style={{ marginBottom: 8 }}>Recent Payments</Text>}
        renderItem={({ item }) => <PaymentCard payment={item} />}
        ListEmptyComponent={<Text style={{ padding: 16 }}>No payments yet.</Text>}
      />
    </View>
  );
}
