
import React from "react";
import { FlatList, RefreshControl, View } from "react-native";
import { Text } from "react-native-paper";
import { useQuery } from "@tanstack/react-query";
import { getPaymentHistoryApi } from "../api/payments";
import PaymentCard from "../components/PaymentCard";

export default function HistoryScreen() {
  const { data, refetch, isFetching } = useQuery({
    queryKey: ["history", { page: 1 }],
    queryFn: () => getPaymentHistoryApi({ page: 1 }),
  });

  const results = data?.results ?? [];

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={results}
        keyExtractor={(item, idx) => String(item.id ?? idx)}
        refreshControl={<RefreshControl refreshing={isFetching} onRefresh={refetch} />}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        ListHeaderComponent={<Text variant="titleMedium" style={{ marginBottom: 8 }}>Payment History</Text>}
        renderItem={({ item }) => <PaymentCard payment={item} />}
        ListEmptyComponent={<Text style={{ padding: 16 }}>No payments found.</Text>}
      />
    </View>
  );
}
