module.exports = {
  presets: ['babel-preset-expo'],
  plugins: [
    'react-native-reanimated/plugin'
    // or 'react-native-worklets/plugin' if Reanimated warns about it
  ],
};
